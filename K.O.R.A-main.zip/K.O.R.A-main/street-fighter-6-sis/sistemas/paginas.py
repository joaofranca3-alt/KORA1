from django.shortcuts import render


def pagina_login(request):
    return render(request, "login.html")


def pagina_inicio(request):
    return render(request, "inicio.html")


def pagina_classificacao(request):
    return render(request, "classificação.html")