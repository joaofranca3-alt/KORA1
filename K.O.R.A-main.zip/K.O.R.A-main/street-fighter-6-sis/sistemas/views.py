from django.views.decorators.http import require_GET, require_POST
from django.views.decorators.csrf import csrf_protect, ensure_csrf_cookie
from drf_spectacular.utils import extend_schema
from drf_spectacular.types import OpenApiTypes
from rest_framework.decorators import api_view
import json
import random
from functools import wraps
from uuid import uuid4
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import Group, User
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.db import transaction
from django.db.models import Q
from django.http import JsonResponse
from django.middleware.csrf import get_token
from .forms import CadastroEquipeForm, JogadorForm, PartidaForm, TorneioForm
from .models import Jogadores, Partida, PartidaParticipante, Torneio, TorneioJogadores, Usuarios

def documentar(corpo=False):
    return extend_schema(
        request=OpenApiTypes.OBJECT if corpo else None,
        responses=OpenApiTypes.OBJECT
    )

ORDEM = ["Oitavas de final", "Quartas de final", "Semifinal", "Final"]
VAGAS = {"Oitavas de final": 8, "Quartas de final": 4, "Semifinal": 2, "Final": 1}
PRIMEIRA_FASE = {4: "Semifinal", 8: "Quartas de final", 16: "Oitavas de final"}
POSICAO = {"Final": 2, "Semifinal": 3, "Quartas de final": 5, "Oitavas de final": 9}

def erro(msg, status=400):
    return JsonResponse({"erro": msg}, status=status)

def tem_grupo(user, nome):
    return user.is_authenticated and user.groups.filter(name=nome).exists()

def metodo(verbo, papel=None, corpo=False):
    def decorar(view):
        @wraps(view)
        def wrapper(request, *args, **kwargs):
            if request.method != verbo:
                return erro("Método não permitido.", 405)
            if papel and not request.user.is_authenticated:
                return erro("Faça login para continuar.", 401)
            if papel and not tem_grupo(request.user, papel):
                return erro("Você não possui permissão.", 403)
            if corpo:
                try:
                    dados = json.loads(request.body)
                except ValueError:
                    dados = None
                if not isinstance(dados, dict):
                    return erro("JSON inválido.")
                args = (dados, *args)
            return view(request, *args, **kwargs)
        return wrapper
    return decorar

def email_de(user):
    return user.email or user.username

def int_positivo(valor):
    try:
        n = int(valor)
    except (TypeError, ValueError):
        return None
    return n if n > 0 and not isinstance(valor, bool) else None

def flag(valor, padrao):
    if valor is None:
        return padrao
    return True if valor in (True, 1, "true", "1") else False if valor in (False, 0, "false", "0") else None

def dados_conta(user):
    grupos = list(user.groups.values_list("name", flat=True))
    return {"usuario": user.username, "grupos": grupos, "papel": grupos[0] if grupos else None}

def pode_ver(request, t):
    u = request.user
    if t.publico:
        return True
    if not u.is_authenticated:
        return False
    if u.is_superuser or t.organizador_id == u.id:
        return True
    if tem_grupo(u, "juiz") and t.id in request.session.get("torneios_privados_juiz", []):
        return True
    return TorneioJogadores.objects.filter(torneio=t, jogador__email__iexact=email_de(u)).exists()

def pode_gerenciar(request, t):
    return tem_grupo(request.user, "organizador") and t.organizador_id in (None, request.user.id)

def pode_excluir(request, t):
    u = request.user
    if not tem_grupo(u, "organizador"):
        return False
    if t.organizador_id is not None:
        return t.organizador_id == u.id
    criadores = set(Partida.objects.filter(torneio=t).values_list("usuario__login", flat=True))
    return criadores == {u.username}

def achar_torneio(request, valor, gerenciar=False, msg="Você não pode gerenciar este torneio."):
    n = int_positivo(valor)
    t = Torneio.objects.filter(id=n).first() if n else None
    if t is None or (not gerenciar and not pode_ver(request, t)):
        return None, erro("Torneio não encontrado.", 404)
    if gerenciar and not pode_gerenciar(request, t):
        return None, erro(msg, 403)
    return t, None

def codigo_livre(codigo, ignorar_id=None):
    return not Torneio.objects.filter(codigo__iexact=codigo).exclude(id=ignorar_id).exists()

def validar_torneio(nome, codigo, publico, ignorar_id=None):
    if not nome or len(nome) > 45 or len(codigo) > 45 or publico is None:
        return None, erro("Nome ou visibilidade inválidos.")
    if publico and not codigo:
        while not codigo_livre(codigo := "PUB-" + uuid4().hex[:8].upper()):
            pass
    elif not publico and len(codigo) < 6:
        return None, erro("O código da sala privada deve ter pelo menos 6 caracteres.")
    if not codigo_livre(codigo, ignorar_id):
        return None, erro("Este código de torneio já está em uso.")
    return codigo, None

def dados_jogador(j):
    return {"id": j.id, "nome": j.nome, "nick": j.nick, "email": j.email}

def inscritos(t):
    return list(TorneioJogadores.objects.filter(torneio=t).select_related("jogador").order_by("id"))

def participantes(partida):
    return list(PartidaParticipante.objects.filter(partida=partida).select_related("jogador").order_by("id"))

def vencedor_da_partida(partida):
    v = [p.jogador for p in participantes(partida) if p.vitoria]
    return v[0] if len(v) == 1 else None

def dados_partida(partida):
    ps = participantes(partida)
    return {
        "id": partida.id,
        "fase": partida.fase,
        "vencedor": next((p.jogador.nick for p in ps if p.vitoria), None),
        "jogadores": [
            {"id": p.jogador_id, "nome": p.jogador.nome, "nick": p.jogador.nick, "vitoria": p.vitoria}
            for p in ps
        ],
    }

def dados_torneio(t, request):
    u = request.user
    dono = u.is_authenticated and (u.is_superuser or t.organizador_id == u.id)
    return {"id": t.id, "nome": t.nome, "codigo": t.codigo if t.publico or dono else None, "publico": t.publico}

def partidas_do_torneio(t):
    return [dados_partida(p) for p in Partida.objects.filter(torneio=t).order_by("id")]

def criar_fase(t, fase, jogadores, usuario):
    with transaction.atomic():
        for i in range(0, len(jogadores), 2):
            partida = Partida.objects.create(torneio=t, fase=fase, usuario=usuario)
            for j in jogadores[i:i + 2]:
                PartidaParticipante.objects.create(torneio=t, partida=partida, jogador=j)

def usuario_organizador(request):
    return Usuarios.objects.get_or_create(
        login=request.user.username, defaults={"senha": "", "papel": "organizador"}
    )[0]

def vencedores_fase(t, fase):
    partidas = list(Partida.objects.filter(torneio=t, fase=fase).order_by("id"))
    if len(partidas) != VAGAS[fase]:
        return None
    vencedores = [vencedor_da_partida(p) for p in partidas]
    return vencedores if all(vencedores) else None

def validar_conta(email, senha):
    try:
        validate_email(email)
        validate_password(senha)
    except ValidationError as exc:
        return erro(" ".join(exc.messages))
    if User.objects.filter(Q(username__iexact=email) | Q(email__iexact=email)).exists():
        return erro("Já existe uma conta com este e-mail.")

def nova_conta(nome, email, senha, papel):
    conta = User.objects.create_user(username=email, email=email, password=senha, first_name=nome)
    conta.groups.add(Group.objects.get_or_create(name=papel)[0])

@ensure_csrf_cookie
@require_GET
def obter_csrf(request):
    return JsonResponse({"csrfToken": get_token(request)})

@csrf_protect
@require_POST
def login_usuario(request):
    try:
        dados = json.loads(request.body)
    except (ValueError, TypeError):
        return erro("JSON inválido.")

    if not isinstance(dados, dict):
        return erro("JSON inválido.")

    usuario = dados.get("login")
    senha = dados.get("senha")

    if (
        not isinstance(usuario, str)
        or not isinstance(senha, str)
        or not usuario.strip()
        or not senha
    ):
        return erro("Informe o usuário e a senha.")

    conta = authenticate(
        request,
        username=usuario.strip(),
        password=senha
    )

    if conta is None:
        return erro("Usuário ou senha incorretos.", 401)

    login(request, conta)

    request.session.save()

    return JsonResponse({
        **dados_conta(conta),
        "autenticado": True
    })

@csrf_protect
@require_POST
def logout_usuario(request):
    logout(request)

    return JsonResponse({
        "mensagem": "Logout realizado com sucesso.",
        "autenticado": False
    })


@require_GET
def consultar_usuario(request):
    if not request.user.is_authenticated:
        return erro("Usuário não autenticado.", 401)

    return JsonResponse({
        **dados_conta(request.user),
        "autenticado": True
    })

@documentar(corpo=True)
@api_view(["POST"])
@metodo("POST", corpo=True)
def cadastrar_jogador(request, dados):
    form = JogadorForm(dados)
    if not form.is_valid():
        return erro("Preencha nome, nick, e-mail e senha corretamente.")
    nome, nick, senha = (form.cleaned_data[c] for c in ("nome", "nick", "senha"))
    email = form.cleaned_data["email"].lower()

    resp = validar_conta(email, senha)
    if resp:
        return resp
    if Jogadores.objects.filter(email__iexact=email).exists():
        return erro("Já existe um jogador com este e-mail.")
    if Jogadores.objects.filter(nick__iexact=nick).exists():
        return erro("Este nick já está em uso.")

    with transaction.atomic():
        nova_conta(nome, email, senha, "jogador")
        jogador = Jogadores.objects.create(nome=nome, nick=nick, email=email)
    return JsonResponse({"id": jogador.id, "mensagem": "Jogador cadastrado com sucesso."}, status=201)

@documentar(corpo=True)
@api_view(["POST"])
@metodo("POST", corpo=True)
def cadastrar_equipe(request, dados):
    form = CadastroEquipeForm(dados)
    if not form.is_valid():
        return erro("Preencha nome, e-mail, senha e função corretamente.")
    nome, senha, papel = (form.cleaned_data[c] for c in ("nome", "senha", "papel"))
    email = form.cleaned_data["email"].lower()

    resp = validar_conta(email, senha)
    if resp:
        return resp

    with transaction.atomic():
        nova_conta(nome, email, senha, papel)
        Usuarios.objects.create(login=email, senha="", papel=papel)
    return JsonResponse({"mensagem": "Conta criada com sucesso.", "usuario": email}, status=201)

def jogador_logado(request):
    return Jogadores.objects.filter(email__iexact=email_de(request.user)).first()

@documentar()
@api_view(["GET"])
@metodo("GET", "jogador")
def consultar_meu_jogador(request):
    jogador = jogador_logado(request)
    if jogador is None:
        return erro("Perfil de jogador não encontrado.", 404)
    return JsonResponse(dados_jogador(jogador))

@documentar()
@api_view(["GET"])
@metodo("GET")
def listar_torneios(request):
    return JsonResponse({
        "torneios": [dados_torneio(t, request) for t in Torneio.objects.order_by("id") if pode_ver(request, t)]
    })

@documentar(corpo=True)
@api_view(["POST"])
@metodo("POST", "juiz", corpo=True)
def entrar_torneio_privado_juiz(request, dados):
    codigo = dados.get("codigo")
    if not isinstance(codigo, str) or not 6 <= len(codigo.strip()) <= 45:
        return erro("Informe um código de 6 a 45 caracteres.")

    t = Torneio.objects.filter(publico=False, codigo__iexact=codigo.strip()).first()
    if t is None:
        return erro("Código da sala inválido.", 404)

    autorizados = request.session.get("torneios_privados_juiz", [])
    if t.id not in autorizados:
        request.session["torneios_privados_juiz"] = autorizados + [t.id]
    return JsonResponse({"mensagem": "Acesso autorizado.", "torneio_id": t.id, "torneio_nome": t.nome})

@documentar(corpo=True)
@api_view(["POST"])
@metodo("POST", "organizador", corpo=True)
def cadastrar_torneio(request, dados):
    form = TorneioForm(dados)
    if not form.is_valid():
        return erro("Informe um nome válido de até 45 caracteres.")
    nome = form.cleaned_data["nome"]
    codigo, resp = validar_torneio(
        nome, form.cleaned_data.get("codigo", "").strip(), flag(dados.get("publico"), True)
    )
    if resp:
        return resp

    publico = flag(dados.get("publico"), True)
    t = Torneio.objects.create(nome=nome, codigo=codigo, publico=publico, organizador=request.user)
    return JsonResponse({"id": t.id, "nome": nome, "codigo": codigo, "publico": publico}, status=201)

@documentar(corpo=True)
@api_view(["PUT"])
@metodo("PUT", "organizador", corpo=True)
def atualizar_torneio(request, dados, torneio_id):
    t, resp = achar_torneio(request, torneio_id, True, "Você não pode alterar este torneio.")
    if resp:
        return resp

    nome, codigo = dados.get("nome", t.nome), dados.get("codigo", t.codigo)
    if not isinstance(nome, str) or not isinstance(codigo, str):
        return erro("Dados inválidos.")
    publico = flag(dados.get("publico"), t.publico)
    codigo, resp = validar_torneio(nome.strip(), codigo.strip(), publico, t.id)
    if resp:
        return resp

    t.nome, t.codigo, t.publico = nome.strip(), codigo, publico
    t.save(update_fields=["nome", "codigo", "publico"])
    return JsonResponse({"id": t.id, "nome": t.nome, "codigo": codigo, "publico": publico})

@documentar(corpo=True)
@api_view(["POST"])
@metodo("POST", "jogador", corpo=True)
def inscrever_jogador(request, dados):
    codigo = dados.get("codigo")
    if isinstance(codigo, str) and codigo.strip():
        t = Torneio.objects.filter(publico=False, codigo__iexact=codigo.strip()).first()
    else:
        t = Torneio.objects.filter(id=int_positivo(dados.get("torneio_id")), publico=True).first()
    if t is None:
        return erro("Torneio não encontrado ou código incorreto.", 404)

    jogador = jogador_logado(request)
    if jogador is None:
        return erro("Perfil de jogador não encontrado.", 404)

    inscricoes = TorneioJogadores.objects.filter(torneio=t)
    if inscricoes.filter(jogador=jogador).exists():
        return erro("Você já está inscrito neste torneio.")
    if Partida.objects.filter(torneio=t).exists():
        return erro("As inscrições deste torneio estão encerradas.")
    if inscricoes.count() >= 16:
        return erro("O torneio já atingiu o limite de 16 jogadores.")

    TorneioJogadores.objects.create(torneio=t, jogador=jogador)
    return JsonResponse({"mensagem": "Inscrição realizada com sucesso.", "torneio_id": t.id, "torneio_nome": t.nome})

@documentar()
@api_view(["GET"])
@metodo("GET")
def listar_inscricoes(request, torneio_id):
    t, resp = achar_torneio(request, torneio_id)
    if resp:
        return resp
    jogadores = [dados_jogador(i.jogador) for i in inscritos(t)]
    return JsonResponse({"torneio_id": t.id, "jogadores": jogadores, "inscritos": jogadores})

@documentar()
@api_view(["GET"])
@metodo("GET")
def consultar_torneio(request, torneio_id):
    t, resp = achar_torneio(request, torneio_id)
    if resp:
        return resp
    jogadores = [dados_jogador(i.jogador) for i in inscritos(t)]
    partidas = partidas_do_torneio(t)
    return JsonResponse({
        **dados_torneio(t, request),
        "total_jogadores": len(jogadores),
        "total_partidas": len(partidas),
        "jogadores": jogadores,
        "partidas": partidas,
        "pode_gerenciar": pode_gerenciar(request, t),
        "pode_excluir": pode_excluir(request, t),
    })

@documentar()
@api_view(["GET"])
@metodo("GET")
def consultar_classificacao(request, torneio_id):
    t, resp = achar_torneio(request, torneio_id)
    if resp:
        return resp

    tabela = {
        i.jogador_id: {
            "id": i.jogador.id, "nick": i.jogador.nick, "nome": i.jogador.nome,
            "vitorias": 0, "derrotas": 0, "partidas_disputadas": 0, "posicao": None, "campeao": False,
        }
        for i in inscritos(t)
    }
    for partida in Partida.objects.filter(torneio=t).order_by("id"):
        ps = participantes(partida)
        vencedores = [p.jogador_id for p in ps if p.vitoria]
        if len(ps) != 2 or len(vencedores) != 1:
            continue
        for p in ps:
            item = tabela.get(p.jogador_id)
            if item is None:
                continue
            item["partidas_disputadas"] += 1
            if p.jogador_id == vencedores[0]:
                item["vitorias"] += 1
            else:
                item["derrotas"] += 1
                item["posicao"] = POSICAO.get(partida.fase)
        if partida.fase == "Final" and vencedores[0] in tabela:
            tabela[vencedores[0]].update(posicao=1, campeao=True)

    ordenada = sorted(
        tabela.values(),
        key=lambda x: (x["posicao"] is None, x["posicao"] or 99, -x["vitorias"], x["nick"].lower()),
    )
    return JsonResponse({"torneio_id": t.id, "classificacao": ordenada})

@documentar()
@api_view(["DELETE"])
@metodo("DELETE", "organizador")
def excluir_torneio(request, torneio_id):
    with transaction.atomic():
        t = Torneio.objects.select_for_update().filter(id=torneio_id).first()
        if t is None:
            return erro("Campeonato não encontrado.", 404)
        if not pode_excluir(request, t):
            return erro("Somente o criador pode excluir este campeonato.", 403)

        finais = list(Partida.objects.filter(torneio=t, fase="Final"))
        if len(finais) != 1:
            return erro("Só é possível excluir um campeonato concluído.", 409)
        if vencedor_da_partida(finais[0]) is None:
            return erro("Confirme o campeão antes de excluir o campeonato.", 409)
        t.delete()
    return JsonResponse({"mensagem": "Campeonato excluído com sucesso."})

@documentar(corpo=True)
@api_view(["POST"])
@metodo("POST", "organizador", corpo=True)
def sortear_confrontos(request, dados):
    t, resp = achar_torneio(request, dados.get("torneio_id"), True)
    if resp:
        return resp

    jogadores = [i.jogador for i in inscritos(t)]
    if len(jogadores) not in PRIMEIRA_FASE:
        return erro("O torneio precisa ter exatamente 4, 8 ou 16 jogadores.")
    if Partida.objects.filter(torneio=t).exists():
        return erro("Os confrontos deste torneio já foram criados.")

    random.shuffle(jogadores)
    fase = PRIMEIRA_FASE[len(jogadores)]
    criar_fase(t, fase, jogadores, usuario_organizador(request))
    return JsonResponse({"mensagem": "Confrontos sorteados.", "fase": fase})

def _avancar(request, dados, origem=None):
    t, resp = achar_torneio(request, dados.get("torneio_id"), True)
    if resp:
        return resp
    if Partida.objects.filter(torneio=t, fase="Final").exists():
        return erro("A final já foi criada.")

    existentes = [f for f in ORDEM[:-1] if Partida.objects.filter(torneio=t, fase=f).exists()]
    origem = origem or (existentes[-1] if existentes else None)
    if origem is None:
        return erro("Ainda não há uma fase para avançar.")

    destino = ORDEM[ORDEM.index(origem) + 1]
    if Partida.objects.filter(torneio=t, fase=destino).exists():
        return erro("A próxima fase já foi criada.")
    vencedores = vencedores_fase(t, origem)
    if vencedores is None:
        return erro("Confirme todos os resultados da fase atual antes de avançar.")

    criar_fase(t, destino, vencedores, usuario_organizador(request))
    return JsonResponse({"mensagem": "Próxima fase criada.", "fase": destino})

@documentar(corpo=True)
@api_view(["POST"])
@metodo("POST", "organizador", corpo=True)
def avancar_fase(request, dados):
    return _avancar(request, dados)

@documentar(corpo=True)
@api_view(["POST"])
@metodo("POST", "organizador", corpo=True)
def gerar_final(request, dados):
    return _avancar(request, dados, "Semifinal")

@documentar(corpo=True)
@api_view(["POST"])
@metodo("POST", "organizador", corpo=True)
def criar_partida(request, dados):
    form = PartidaForm(dados)
    if not form.is_valid():
        return erro("Informe torneio, dois jogadores e fase válidos.")
    v = form.cleaned_data

    t, resp = achar_torneio(request, v["torneio_id"], True)
    if resp:
        return resp

    ids = [i.jogador_id for i in inscritos(t)]
    if len(ids) not in PRIMEIRA_FASE:
        return erro("O torneio precisa ter 4, 8 ou 16 inscritos.")

    j1, j2, fase = v["jogador1_id"], v["jogador2_id"], v["fase"]
    if j1 == j2 or j1 not in ids or j2 not in ids:
        return erro("Selecione dois jogadores diferentes inscritos no torneio.")

    anterior = ORDEM[ORDEM.index(fase) - 1] if fase in ORDEM and ORDEM.index(fase) > 0 else None
    if fase == PRIMEIRA_FASE[len(ids)]:
        permitidos = ids
    elif anterior and Partida.objects.filter(torneio=t, fase=anterior).exists():
        permitidos = [j.id for j in vencedores_fase(t, anterior) or []]
    else:
        return erro("Esta fase não corresponde ao formato do torneio.")

    if j1 not in permitidos or j2 not in permitidos:
        return erro("Os jogadores não estão classificados para esta fase.")
    if Partida.objects.filter(torneio=t, fase=fase).count() >= VAGAS[fase]:
        return erro("Todas as partidas desta fase já foram criadas.")
    if PartidaParticipante.objects.filter(partida__torneio=t, partida__fase=fase, jogador_id__in=[j1, j2]).exists():
        return erro("Um jogador já está em uma partida desta fase.")

    jogadores = [Jogadores.objects.get(id=j1), Jogadores.objects.get(id=j2)]
    criar_fase(t, fase, jogadores, usuario_organizador(request))
    return JsonResponse({"mensagem": "Partida criada com sucesso."})

@documentar()
@api_view(["GET"])
@metodo("GET")
def listar_partidas(request, torneio_id):
    t, resp = achar_torneio(request, torneio_id)
    if resp:
        return resp
    return JsonResponse({"torneio_id": t.id, "partidas": partidas_do_torneio(t)})

@documentar()
@api_view(["GET"])
@metodo("GET")
def consultar_partida(request, partida_id):
    partida = Partida.objects.select_related("torneio").filter(id=partida_id).first()
    if partida is None or not pode_ver(request, partida.torneio):
        return erro("Partida não encontrada.", 404)
    return JsonResponse(dados_partida(partida))

@documentar(corpo=True)
@api_view(["PUT"])
@metodo("PUT", "juiz", corpo=True)
def registrar_resultado(request, dados, partida_id):
    vencedor_id = int_positivo(dados.get("vencedor_id"))
    if not vencedor_id or dados.get("confirmado") is not True:
        return erro("Informe e confirme o vencedor.")

    final_gerada = False
    with transaction.atomic():
        partida = Partida.objects.select_related("torneio").filter(id=partida_id).first()
        if partida is None or not pode_ver(request, partida.torneio):
            return erro("Partida não encontrada.", 404)

        torneio = Torneio.objects.select_for_update().get(id=partida.torneio_id)
        ps = list(PartidaParticipante.objects.select_for_update().filter(partida=partida).order_by("id"))

        if len(ps) != 2 or ps[0].jogador_id == ps[1].jogador_id:
            return erro("Esta partida precisa ter dois jogadores diferentes.")
        if any(p.vitoria for p in ps):
            return erro("O resultado desta partida já foi confirmado.")
        vencedor = next((p for p in ps if p.jogador_id == vencedor_id), None)
        if vencedor is None:
            return erro("O vencedor deve participar desta partida.")

        vencedor.vitoria = True
        vencedor.save(update_fields=["vitoria"])

        if partida.fase == "Semifinal" and not Partida.objects.filter(torneio=torneio, fase="Final").exists():
            vencedores = vencedores_fase(torneio, "Semifinal")
            if vencedores and vencedores[0].id != vencedores[1].id:
                criar_fase(torneio, "Final", vencedores, partida.usuario)
                final_gerada = True

    return JsonResponse({"mensagem": "Resultado confirmado.", "vencedor_id": vencedor_id, "final_gerada": final_gerada})