"use strict";

const MAX_JOGADORES = 16;
const paragrafos = (pai, ...linhas) =>
    linhas.forEach((texto) => adicionar(pai, "p", texto));

const linkTorneio = (texto, id) =>
    criarLink(texto, `/classificacao/?torneio=${id}`);

const resumoPerfil = (p) => `${p.nome} | Nick: ${p.nick} | E-mail: ${p.email}`;

function bloqueioInscricao(detalhes) {
    const inscrito = KORA.perfil && detalhes?.jogadores.some(
        (j) => j.id === KORA.perfil.id
    );

    if (inscrito) return ["Já inscrito", "Você já participa deste torneio."];
    if (detalhes?.total_partidas > 0) return ["Inscrições encerradas", "O torneio já começou."];
    if (detalhes?.total_jogadores >= MAX_JOGADORES) return ["Vagas esgotadas", "Limite de 16 jogadores atingido."];
    if (!KORA.perfil) return ["Participar", "Não foi possível carregar seu perfil de jogador."];
    return null;
}

function criarAcoesJogador(torneio, detalhes, recarregar, mensagem) {
    const acoes = criar("div");

    if (!torneio.publico) {
        const inscrito = KORA.perfil && detalhes?.jogadores.some(
            (j) => j.id === KORA.perfil.id
        );
        if (inscrito) paragrafos(acoes, "Você já está inscrito neste torneio privado.");
        return acoes;
    }

    const participar = criarBotao("Participar", () =>
        executar(participar, mensagem, async () => {
            await api("/api/inscricoes/cadastrar/", "POST", { torneio_id: torneio.id });
            avisar(mensagem, `Inscrição realizada no torneio ${torneio.nome}!`);
            await recarregar();
        })
    );

    const bloqueio = bloqueioInscricao(detalhes);
    if (bloqueio) {
        participar.textContent = bloqueio[0];
        habilitar(participar, false, bloqueio[1]);
    }

    acoes.appendChild(participar);
    return acoes;
}

function criarBotaoExcluir(torneio, recarregar, mensagem) {
    const excluir = criarBotao("Apagar campeonato", async () => {
        const confirmou = window.confirm(
            `Apagar definitivamente o campeonato "${torneio.nome}"? ` +
            "As inscrições, partidas e resultados serão excluídos. " +
            "Esta ação não pode ser desfeita."
        );
        if (!confirmou) return;

        await executar(excluir, mensagem, async () => {
            await api(`/api/torneios/excluir/${torneio.id}/`, "DELETE");
            await recarregar();
            avisar(mensagem, "Campeonato apagado com sucesso.");
        });
    });
    return excluir;
}

function criarCardTorneio(torneio, detalhes, recarregar, mensagem) {
    const card = criar("article");
    adicionar(card, "h3", torneio.nome);

    paragrafos(
        card,
        torneio.publico ? "Torneio público" : "Torneio privado",
        ...(!torneio.publico && torneio.codigo ? [`Código da sala: ${torneio.codigo}`] : []),
        "Jogo: Street Fighter 6 | Eliminação simples"
    );

    if (detalhes) {
        paragrafos(
            card,
            `Participantes inscritos: ${detalhes.total_jogadores}`,
            detalhes.total_partidas > 0
                ? "Situação: torneio iniciado (inscrições encerradas)"
                : "Situação: inscrições abertas"
        );
    } else {
        paragrafos(card, "Não foi possível consultar os participantes.");
    }

    const acoes = temPapel("jogador")
        ? criarAcoesJogador(torneio, detalhes, recarregar, mensagem)
        : criar("div");

    acoes.prepend(linkTorneio("Ver torneio e classificação", torneio.id));

    if (!temPapel("jogador") && !KORA.usuario) {
        acoes.appendChild(criarLink("Entrar para participar", "/login/"));
    }

    const finalDecidida = detalhes?.partidas.some(
        (p) => p.fase === "Final" && p.vencedor
    );
    if (temPapel("organizador") && detalhes?.pode_excluir && finalDecidida) {
        acoes.appendChild(criarBotaoExcluir(torneio, recarregar, mensagem));
    }

    card.appendChild(acoes);
    return card;
}

async function carregarTorneios(lista, mensagem) {
    lista.replaceChildren();

    const { torneios } = await api("/api/torneios/");

    if (!torneios.length) {
        adicionar(lista, "p", "Nenhum torneio público disponível no momento.");
        return;
    }

    const detalhes = await Promise.all(
        torneios.map((t) => api(`/api/torneios/detalhes/${t.id}/`).catch(() => null))
    );

    const recarregar = () => carregarTorneios(lista, mensagem);

    torneios.forEach((torneio, i) =>
        lista.appendChild(criarCardTorneio(torneio, detalhes[i], recarregar, mensagem))
    );
}

function criarCadastroTorneio(principal, lista, mensagemLista) {
    const painel = criar("section");
    painel.id = "painel-cadastro-torneio";

    adicionar(painel, "h2", "Cadastrar campeonato");
    adicionar(
        painel,
        "p",
        "O campeonato pode ser criado antes das inscrições. Para iniciar, utilize 4, 8 ou 16 jogadores."
    );

    const formulario = criar("form");
    const nome = criarCampo(formulario, "Nome do campeonato", "torneio-nome");

    const rotuloTipo = criar("label", "Visibilidade do campeonato");
    rotuloTipo.htmlFor = "torneio-tipo";

    const tipo = criar("select");
    tipo.id = tipo.name = "torneio-tipo";
    [["publico", "Público"], ["privado", "Privado"]].forEach(([valor, texto]) => {
        const opcao = criar("option", texto);
        opcao.value = valor;
        tipo.appendChild(opcao);
    });

    const grupoTipo = criar("div");
    grupoTipo.append(rotuloTipo, tipo);
    formulario.appendChild(grupoTipo);

    const codigo = criarCampo(formulario, "Código da sala privada", "torneio-codigo");
    codigo.minLength = 6;
    codigo.maxLength = 45;

    const ehPrivado = () => tipo.value === "privado";

    function atualizarTipo() {
        codigo.parentElement.style.display = ehPrivado() ? "" : "none";
        codigo.required = ehPrivado();
        if (!ehPrivado()) codigo.value = "";
    }

    tipo.addEventListener("change", atualizarTipo);
    atualizarTipo();

    const cadastrar = criar("button", "Criar campeonato");
    cadastrar.type = "submit";
    formulario.appendChild(cadastrar);
    painel.appendChild(formulario);

    const retorno = criarMensagem(painel);
    principal.appendChild(painel);

    formulario.addEventListener("submit", (evento) => {
        evento.preventDefault();

        return executar(cadastrar, retorno, async () => {
            const privado = ehPrivado();

            const resposta = await api("/api/torneios/cadastrar/", "POST", {
                nome: nome.value.trim(),
                publico: !privado,
                codigo: privado ? codigo.value.trim() : ""
            });

            formulario.reset();
            atualizarTipo();

            avisar(
                retorno,
                privado
                    ? `Campeonato privado criado! Código: ${resposta.codigo}`
                    : "Campeonato público criado com sucesso!"
            );

            await carregarTorneios(lista, mensagemLista);
            retorno.append(" ", linkTorneio("Abrir o novo campeonato", resposta.id));
        });
    });
}

function criarEntradaPrivada(principal, lista, mensagemLista) {
    const ehJuiz = temPapel("juiz");

    const painel = criar("section");
    painel.id = "painel-torneio-privado";
    adicionar(painel, "h2", "Torneio privado");

    const formulario = criar("form");
    formulario.style.display = "none";

    painel.appendChild(
        criarBotao("Entrar em torneio privado", () => {
            formulario.style.display = formulario.style.display === "none" ? "" : "none";
        })
    );

    const codigo = criarCampo(formulario, "Código da sala", "codigo-sala-privada");
    codigo.minLength = 6;

    const entrar = criar("button", "Entrar na sala");
    entrar.type = "submit";
    formulario.appendChild(entrar);
    painel.appendChild(formulario);

    const retorno = criarMensagem(painel);
    principal.appendChild(painel);

    formulario.addEventListener("submit", (evento) => {
        evento.preventDefault();

        return executar(entrar, retorno, async () => {
            const resposta = await api(
                ehJuiz ? "/api/torneios/juiz/entrar/" : "/api/inscricoes/cadastrar/",
                "POST",
                { codigo: codigo.value.trim() }
            );

            codigo.value = "";
            formulario.style.display = "none";

            avisar(
                retorno,
                ehJuiz
                    ? `Acesso de juiz autorizado no torneio ${resposta.torneio_nome}!`
                    : `Você entrou no torneio ${resposta.torneio_nome}!`
            );

            await carregarTorneios(lista, mensagemLista);
            retorno.append(" ", linkTorneio("Ver torneio", resposta.torneio_id));
        });
    });
}

function criarPainelPerfil(principal) {
    const painel = criar("section");
    painel.id = "painel-perfil";
    painel.style.display = window.location.hash === "#painel-perfil" ? "" : "none";

    adicionar(painel, "h2", "Meu perfil de jogador");

    const retorno = criarMensagem(painel);

    const consultar = criarBotao("Consultar meu perfil", () =>
        executar(consultar, retorno, async () => {
            KORA.perfil = await api("/api/jogadores/meu-perfil/");
            avisar(retorno, resumoPerfil(KORA.perfil));
        })
    );

    painel.insertBefore(consultar, retorno);
    principal.appendChild(painel);

    if (KORA.perfil) avisar(retorno, resumoPerfil(KORA.perfil));

    const link = document.querySelector('header nav a[href$="#painel-perfil"]');
    if (!link) return;

    const aberto = () => painel.style.display !== "none";

    link.setAttribute("aria-controls", painel.id);
    link.setAttribute("aria-expanded", String(aberto()));

    link.addEventListener("click", (evento) => {
        evento.preventDefault();

        painel.style.display = aberto() ? "none" : "";
        link.setAttribute("aria-expanded", String(aberto()));

        if (aberto()) {
            painel.scrollIntoView({ behavior: "smooth", block: "start" });
        }
    });
}

async function iniciarInicio() {
    const principal = document.querySelector("main");
    const secao = buscar("torneios-publicos");

    secao.replaceChildren();
    adicionar(secao, "h2", "Torneios disponíveis");

    const lista = criar("div");
    lista.id = "lista-torneios";
    secao.appendChild(lista);

    const mensagem = criarMensagem(secao, "mensagem-torneios");

    principal.insertBefore(
        criar(
            "p",
            KORA.usuario
                ? `Conectado como ${KORA.usuario.usuario}`
                : "Você está visualizando os torneios como visitante."
        ),
        secao
    );

    if (temPapel("jogador")) {
        try {
            KORA.perfil = await api("/api/jogadores/meu-perfil/");
        } catch (erro) {
            avisar(mensagem, `Perfil de jogador: ${erro.message}`, true);
        }
        criarPainelPerfil(principal);
    }

    if (temPapel("jogador") || temPapel("juiz")) {
        criarEntradaPrivada(principal, lista, mensagem);
    }

    if (temPapel("organizador")) {
        criarCadastroTorneio(principal, lista, mensagem);
    }

    try {
        await carregarTorneios(lista, mensagem);
    } catch (erro) {
        avisar(mensagem, erro.message, true);
    }
}