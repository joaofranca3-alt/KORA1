"use strict";

const adicionarParagrafos = (pai, ...linhas) =>
    linhas.forEach((texto) => adicionar(pai, "p", texto));

const pesoDaFase = (fase) => FASES.indexOf(fase) + 1 || 99;

function mostrarInformacoes(secao, detalhes, classificacao) {
    secao.replaceChildren();

    const campeao = classificacao.find((jogador) => jogador.campeao);
    const situacao = campeao
        ? "Concluído"
        : detalhes.total_partidas > 0
            ? "Em andamento"
            : "Inscrições abertas";

    adicionar(secao, "h2", detalhes.nome);
    adicionarParagrafos(
        secao,
        "Street Fighter 6 | Eliminação simples",
        detalhes.publico ? "Torneio público" : "Torneio privado",
        ...(!detalhes.publico && detalhes.codigo ? [`Código da sala: ${detalhes.codigo}`] : []),
        `Jogadores inscritos: ${detalhes.total_jogadores}`,
        `Partidas criadas: ${detalhes.total_partidas}`,
        `Situação: ${situacao}`,
        ...(campeao ? [`Campeão: ${campeao.nick}`] : [])
    );
}

function mostrarInscritos(secao, jogadores) {
    secao.replaceChildren();
    adicionar(secao, "h2", "Jogadores inscritos");

    if (!jogadores.length) {
        adicionar(secao, "p", "Nenhum jogador inscrito ainda.");
        return;
    }

    const lista = criar("ul");
    jogadores.forEach((j) => adicionar(lista, "li", `${j.nick} (${j.nome})`));
    secao.appendChild(lista);
}

function criarEscolhaVencedor(partida, mensagem, atualizar) {
    const label = criar("label", "Selecione o vencedor");

    const seletor = criar("select");
    seletor.id = `vencedor-partida-${partida.id}`;
    label.htmlFor = seletor.id;
    preencherSelect(seletor, partida.jogadores);

    const confirmar = criarBotao("Confirmar vencedor", async () => {
        const vencedorId = Number(seletor.value);

        if (!vencedorId) {
            avisar(mensagem, "Selecione o jogador vencedor.", true);
            return;
        }

        const confirmou = window.confirm(
            "Confirmar este vencedor? O resultado não poderá ser alterado pela interface."
        );
        if (!confirmou) return;

        await executar(confirmar, mensagem, async () => {
            await api(`/api/partidas/resultado/${partida.id}/`, "PUT", {
                vencedor_id: vencedorId,
                confirmado: true
            });
            await atualizar();
            avisar(mensagem, "Resultado confirmado com sucesso!");
        });
    });

    return [label, seletor, confirmar];
}

function mostrarPartidas(secao, partidas, mensagem, atualizar) {
    secao.replaceChildren();
    adicionar(secao, "h2", "Confrontos e resultados");

    if (!partidas.length) {
        adicionar(secao, "p", "Os confrontos ainda não foram criados.");
        return;
    }

    const ordenadas = [...partidas].sort(
        (a, b) => pesoDaFase(a.fase) - pesoDaFase(b.fase) || a.id - b.id
    );

    ordenadas.forEach((partida) => {
        const card = criar("article");

        adicionar(card, "h3", `${partida.fase} | Partida ${partida.id}`);
        adicionarParagrafos(
            card,
            partida.jogadores.map((j) => j.nick).join(" x "),
            `Vencedor: ${partida.vencedor || "aguardando resultado"}`
        );

        if (temPapel("juiz") && !partida.vencedor && partida.jogadores.length === 2) {
            card.append(...criarEscolhaVencedor(partida, mensagem, atualizar));
        }

        secao.appendChild(card);
    });
}

function mostrarClassificacao(secao, jogadores) {
    secao.replaceChildren();
    adicionar(secao, "h2", "Tabela de classificação");

    const linha = (tag, valores) => {
        const tr = criar("tr");
        valores.forEach((valor) => adicionar(tr, tag, valor));
        return tr;
    };

    const cabecalho = criar("thead");
    cabecalho.appendChild(
        linha("th", ["Posição", "Jogador", "Vitórias", "Derrotas", "Partidas"])
    );

    const corpo = criar("tbody");

    jogadores.forEach((j) =>
        corpo.appendChild(
            linha("td", [
                j.posicao === null ? "Em disputa" : `${j.posicao}º`,
                j.nick,
                j.vitorias,
                j.derrotas,
                j.partidas_disputadas
            ])
        )
    );

    if (!jogadores.length) {
        const vazia = criar("tr");
        const coluna = criar("td", "Ainda não há jogadores inscritos.");
        coluna.colSpan = 5;
        vazia.appendChild(coluna);
        corpo.appendChild(vazia);
    }

    const tabela = criar("table");
    tabela.append(cabecalho, corpo);
    secao.appendChild(tabela);
}

function criarBotaoApagar(detalhes, id, mensagem) {
    const apagar = criarBotao("Apagar campeonato", async () => {
        const confirmou = window.confirm(
            `Apagar definitivamente o campeonato "${detalhes.nome}"? ` +
            "As inscrições, partidas e resultados serão excluídos. Esta ação não pode ser desfeita."
        );
        if (!confirmou) return;

        await executar(apagar, mensagem, async () => {
            await api(`/api/torneios/excluir/${id}/`, "DELETE");
            window.location.href = "/inicio/";
        });
    });
    return apagar;
}

async function listarCampeonatos(informacoes, mensagem) {
    adicionar(informacoes, "h2", "Selecione um campeonato");

    try {
        const { torneios } = await api("/api/torneios/");

        if (!torneios.length) {
            adicionar(informacoes, "p", "Nenhum campeonato cadastrado.");
        }

        torneios.forEach((torneio) => {
            const item = criar("p");
            item.appendChild(
                criarLink(torneio.nome, `/classificacao/?torneio=${torneio.id}`)
            );
            informacoes.appendChild(item);
        });
    } catch (erro) {
        avisar(mensagem, erro.message, true);
    }
}

async function iniciarClassificacao() {
    const principal = document.querySelector("main");
    const informacoes = buscar("informacoes-torneio");
    const confrontos = buscar("proximos-confrontos");
    const classificacao = buscar("classificacao");

    const mensagem = criar("p");
    mensagem.setAttribute("role", "status");
    principal.insertBefore(mensagem, informacoes);

    const id = Number(new URLSearchParams(window.location.search).get("torneio"));

    if (!Number.isInteger(id) || id <= 0) {
        [informacoes, confrontos, classificacao].forEach((s) => s.replaceChildren());
        await listarCampeonatos(informacoes, mensagem);
        return;
    }

    KORA.torneioId = id;

    const inscritos = criar("section");
    inscritos.id = "inscritos";
    principal.insertBefore(inscritos, confrontos);

    async function atualizar() {
        const [detalhes, dados] = await Promise.all([
            api(`/api/torneios/detalhes/${id}/`),
            api(`/api/torneios/classificacao/${id}/`)
        ]);

        const tabela = dados.classificacao;
        KORA.detalhes = detalhes;

        mostrarInformacoes(informacoes, detalhes, tabela);

        if (detalhes.pode_excluir && tabela.some((j) => j.campeao)) {
            informacoes.appendChild(criarBotaoApagar(detalhes, id, mensagem));
        }

        mostrarInscritos(inscritos, detalhes.jogadores);
        mostrarPartidas(confrontos, detalhes.partidas, mensagem, atualizar);
        mostrarClassificacao(classificacao, tabela);

        controles?.atualizar(detalhes);
    }

    const controles = criarPainelOrganizador(principal, mensagem, atualizar);

    try {
        await atualizar();
    } catch (erro) {
        avisar(mensagem, erro.message, true);
        informacoes.replaceChildren();
        adicionar(informacoes, "h2", "Não foi possível carregar o campeonato");
    }
}