"use strict";

async function iniciarKora() {
    const secaoLogin = buscar("login");

    if (secaoLogin && window.location.hash !== "#entrar") {
        secaoLogin.style.display = "none";
    }

    try {
        KORA.usuario = await consultarUsuario();
        configurarMenu();

        if (buscar("login")) {
            iniciarLogin();
        } else if (buscar("torneios-publicos")) {
            await iniciarInicio();
        } else if (buscar("classificacao")) {
            await iniciarClassificacao();
        }
    } catch (erro) {
        const principal = document.querySelector("main");

        if (principal) {
            avisar(
                criarMensagem(principal),
                erro.message,
                true
            );
        }
    }
}

if (document.readyState === "loading") {
    document.addEventListener(
        "DOMContentLoaded",
        iniciarKora
    );
} else {
    iniciarKora();
}
