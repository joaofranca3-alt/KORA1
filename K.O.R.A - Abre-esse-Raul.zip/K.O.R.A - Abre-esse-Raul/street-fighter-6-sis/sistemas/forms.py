
from django import forms


class TorneioForm(forms.Form):
    nome = forms.CharField(max_length=45)
    codigo = forms.CharField(max_length=45, required=False)


class JogadorForm(forms.Form):
    nome = forms.CharField(max_length=45)
    nick = forms.CharField(max_length=45)
    email = forms.CharField(max_length=45)
    senha = forms.CharField()


class PartidaForm(forms.Form):
    torneio_id = forms.IntegerField(min_value=1)
    jogador1_id = forms.IntegerField(min_value=1)
    jogador2_id = forms.IntegerField(min_value=1)
    fase = forms.ChoiceField(choices=[
        ("Oitavas de final", "Oitavas de final"),
        ("Quartas de final", "Quartas de final"),
        ("Semifinal", "Semifinal"),
        ("Final", "Final")
    ])


class CadastroEquipeForm(forms.Form):
    nome = forms.CharField(max_length=45)
    email = forms.EmailField(max_length=45)
    senha = forms.CharField(min_length=8, max_length=128)
    papel = forms.ChoiceField(choices=[
        ("organizador", "Organizador"),
        ("juiz", "Juiz")
    ])
