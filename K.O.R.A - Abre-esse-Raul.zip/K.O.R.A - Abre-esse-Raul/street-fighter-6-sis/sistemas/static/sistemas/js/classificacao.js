
"use strict";

function adicionarParagrafos(pai, ...linhas) {
    linhas.forEach((texto) => adicionar(pai, "p", texto));
}

function pesoDaFase(fase) {
    return FASES.indexOf(fase) + 1 || 99;
}

function mostrarInformacoes(secao, detalhes, classificacao) {
    secao.replaceChildren();

    const campeao = classificacao.find((jogador) => jogador.campeao);

    let situacao = "Inscrições abertas";

    if (detalhes.total_partidas > 0) {
        situacao = "Em andamento";
    }

    if (campeao) {
        situacao = "Concluído";
    }

    adicionar(secao, "h2", detalhes.nome);
    adicionar(secao, "p", "Street Fighter 6 | Eliminação simples");

    if (detalhes.publico) {
        adicionar(secao, "p", "Torneio público");
    } else {
        adicionar(secao, "p", "Torneio privado");
    }

    if (!detalhes.publico && detalhes.codigo) {
        adicionar(secao, "p", `Código da sala: ${detalhes.codigo}`);
    }

    adicionarParagrafos(
        secao,
        `Jogadores inscritos: ${detalhes.total_jogadores}`,
        `Partidas criadas: ${detalhes.total_partidas}`,
        `Situação: ${situacao}`
    );

    if (campeao) {
        adicionar(secao, "p", `Campeão: ${campeao.nick}`);
    }
}

function mostrarInscritos(secao, jogadores) {
    secao.replaceChildren();
    adicionar(secao, "h2", "Jogadores inscritos");

    if (jogadores.length === 0) {
        adicionar(secao, "p", "Nenhum jogador inscrito ainda.");
        return;
    }

    const lista = criar("ul");

    jogadores.forEach((jogador) => {
        adicionar(lista, "li", jogador.nick + " (" + jogador.nome + ")");
    });

    secao.appendChild(lista);
}

function criarEscolhaVencedor(partida, mensagem, atualizar) {
    const label = criar("label", "Selecione o vencedor");
    const seletor = criar("select");

    seletor.id = "vencedor-partida-" + partida.id;
    label.htmlFor = seletor.id;

    preencherSelect(seletor, partida.jogadores);

    const confirmar = criarBotao("Confirmar vencedor", async () => {
        const vencedorId = Number(seletor.value);

        if (!vencedorId) {
            avisar(mensagem, "Selecione o jogador vencedor.", true);
            return;
        }

        if (!window.confirm("Confirmar este vencedor? O resultado não poderá ser alterado pela interface.")) {
            return;
        }

        await executar(confirmar, mensagem, async () => {
            await api("/api/partidas/resultado/" + partida.id + "/", "PUT", {
                vencedor_id: vencedorId,
                confirmado: true
            });

            await atualizar();
            avisar(mensagem, "Resultado confirmado com sucesso!");
        });
    });

    return [label, seletor, confirmar];
}

function mostrarPartidas(secao, partidas, mensagem, atualizar) {
    secao.replaceChildren();
    adicionar(secao, "h2", "Confrontos e resultados");

    if (partidas.length === 0) {
        adicionar(secao, "p", "Os confrontos ainda não foram criados.");
        return;
    }

    partidas.sort((a, b) => {
        return pesoDaFase(a.fase) - pesoDaFase(b.fase) || a.id - b.id;
    });

    partidas.forEach((partida) => {
        const card = criar("article");

        adicionar(card, "h3", partida.fase + " | Partida " + partida.id);

        const nomes = partida.jogadores.map((jogador) => jogador.nick).join(" x ");

        adicionar(card, "p", nomes);
        adicionar(card, "p", "Vencedor: " + (partida.vencedor || "aguardando resultado"));

        if (temPapel("juiz") && !partida.vencedor && partida.jogadores.length === 2) {
            card.append(...criarEscolhaVencedor(partida, mensagem, atualizar));
        }

        secao.appendChild(card);
    });
}

function mostrarClassificacao(secao, jogadores) {
    secao.replaceChildren();
    adicionar(secao, "h2", "Tabela de classificação");

    const tabela = criar("table");
    const cabecalho = criar("thead");
    const corpo = criar("tbody");

    const titulos = ["Posição", "Jogador", "Vitórias", "Derrotas", "Partidas"];
    const linhaCabecalho = criar("tr");

    titulos.forEach((titulo) => {
        adicionar(linhaCabecalho, "th", titulo);
    });

    cabecalho.appendChild(linhaCabecalho);

    jogadores.forEach((jogador) => {
        const linha = criar("tr");

        let posicao = "Em disputa";

        if (jogador.posicao !== null) {
            posicao = jogador.posicao + "º";
        }

        adicionar(linha, "td", posicao);
        adicionar(linha, "td", jogador.nick);
        adicionar(linha, "td", jogador.vitorias);
        adicionar(linha, "td", jogador.derrotas);
        adicionar(linha, "td", jogador.partidas_disputadas);

        corpo.appendChild(linha);
    });

    if (jogadores.length === 0) {
        const linha = criar("tr");
        const coluna = criar("td", "Ainda não há jogadores inscritos.");

        coluna.colSpan = 5;
        linha.appendChild(coluna);
        corpo.appendChild(linha);
    }

    tabela.append(cabecalho, corpo);
    secao.appendChild(tabela);
}

function criarBotaoApagar(detalhes, id, mensagem) {
    const apagar = criarBotao("Apagar campeonato", async () => {
        const confirmou = window.confirm(
            "Apagar definitivamente o campeonato " + detalhes.nome + "? " +
            "As inscrições, partidas e resultados serão excluídos. Esta ação não pode ser desfeita."
        );

        if (!confirmou) {
            return;
        }

        await executar(apagar, mensagem, async () => {
            await api("/api/torneios/excluir/" + id + "/", "DELETE");
            window.location.href = "/inicio/";
        });
    });

    return apagar;
}

async function listarCampeonatos(informacoes, mensagem) {
    adicionar(informacoes, "h2", "Selecione um campeonato");

    try {
        const resposta = await api("/api/torneios/");

        if (resposta.torneios.length === 0) {
            adicionar(informacoes, "p", "Nenhum campeonato cadastrado.");
        }

        resposta.torneios.forEach((torneio) => {
            const item = criar("p");
            const link = criarLink(
                torneio.nome,
                "/classificacao/?torneio=" + torneio.id
            );

            item.appendChild(link);
            informacoes.appendChild(item);
        });
    } catch (erro) {
        avisar(mensagem, erro.message, true);
    }
}

async function iniciarClassificacao() {
    const principal = document.querySelector("main");
    const informacoes = buscar("informacoes-torneio");
    const confrontos = buscar("proximos-confrontos");
    const classificacao = buscar("classificacao");

    const mensagem = criar("p");
    mensagem.setAttribute("role", "status");

    principal.insertBefore(mensagem, informacoes);

    const parametros = new URLSearchParams(window.location.search);
    const id = Number(parametros.get("torneio"));

    if (!Number.isInteger(id) || id <= 0) {
        informacoes.replaceChildren();
        confrontos.replaceChildren();
        classificacao.replaceChildren();

        await listarCampeonatos(informacoes, mensagem);
        return;
    }

    KORA.torneioId = id;

    const inscritos = criar("section");
    inscritos.id = "inscritos";

    principal.insertBefore(inscritos, confrontos);

    async function atualizar() {
        const detalhes = await api("/api/torneios/detalhes/" + id + "/");
        const dados = await api("/api/torneios/classificacao/" + id + "/");

        KORA.detalhes = detalhes;

        mostrarInformacoes(informacoes, detalhes, dados.classificacao);

        if (detalhes.pode_excluir && dados.classificacao.some((jogador) => jogador.campeao)) {
            informacoes.appendChild(criarBotaoApagar(detalhes, id, mensagem));
        }

        mostrarInscritos(inscritos, detalhes.jogadores);
        mostrarPartidas(confrontos, detalhes.partidas, mensagem, atualizar);
        mostrarClassificacao(classificacao, dados.classificacao);

        controles?.atualizar(detalhes);
    }

    const controles = criarPainelOrganizador(principal, mensagem, atualizar);

    try {
        await atualizar();
    } catch (erro) {
        avisar(mensagem, erro.message, true);
        informacoes.replaceChildren();
        adicionar(informacoes, "h2", "Não foi possível carregar o campeonato");
    }
}
