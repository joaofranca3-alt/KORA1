
"use strict";

function iniciarLogin() {
    const secao = buscar("login");
    const formulario = secao.querySelector("form");
    const usuario = buscar("usuario");
    const senha = buscar("senha");

    const mensagem = buscar("mensagem-login") ||
        criarMensagem(secao, "mensagem-login");

    if (KORA.usuario) {
        avisar(
            mensagem,
            `Você já está conectado como ${KORA.usuario.usuario}.`
        );

        secao.appendChild(
            criarLink("Ir para os torneios", "/inicio/")
        );
    }

    formulario.addEventListener("submit", async (evento) => {
        evento.preventDefault();

        const botao = formulario.querySelector(
            'button[type="submit"]'
        );

        await executar(botao, mensagem, async () => {
            await api("/api/login/", "POST", {
                login: usuario.value.trim(),
                senha: senha.value
            });

            avisar(mensagem, "Login realizado! Abrindo os torneios...");

            window.location.href = "/inicio/";
        });
    });

    let cadastro = buscar("cadastro-jogador");

    if (!cadastro) {
        cadastro = criar("section");
        cadastro.id = "cadastro-jogador";

        adicionar(cadastro, "h2", "Criar conta de jogador");

        document.querySelector("main").appendChild(cadastro);
    }

    const formCadastro = criar("form");

    const grupoTipo = criar("div");
    const labelTipo = criar("label", "Tipo de conta");

    labelTipo.htmlFor = "cadastro-tipo";

    const tipo = criar("select");
    tipo.id = "cadastro-tipo";
    tipo.name = "cadastro-tipo";

    const tipos = [
        ["jogador", "Jogador"],
        ["organizador", "Organizador"],
        ["juiz", "Juiz"]
    ];

    tipos.forEach(([valor, titulo]) => {
        const opcao = criar("option", titulo);
        opcao.value = valor;
        tipo.appendChild(opcao);
    });

    grupoTipo.append(labelTipo, tipo);
    formCadastro.appendChild(grupoTipo);

    const nome = criarCampo(
        formCadastro,
        "Nome completo",
        "cadastro-nome"
    );

    const nick = criarCampo(
        formCadastro,
        "Apelido no Street Fighter 6",
        "cadastro-nick"
    );

    const email = criarCampo(
        formCadastro,
        "E-mail",
        "cadastro-email",
        "email"
    );

    const novaSenha = criarCampo(
        formCadastro,
        "Senha (mínimo de 8 caracteres)",
        "cadastro-senha",
        "password"
    );

    const cadastrar = criar("button", "Cadastrar jogador");
    cadastrar.type = "submit";

    formCadastro.appendChild(cadastrar);
    cadastro.appendChild(formCadastro);

    function atualizarTipo() {
        const jogador = tipo.value === "jogador";

        nick.parentElement.style.display = jogador ? "" : "none";
        nick.required = jogador;

        if (jogador) {
            cadastro.querySelector("h2").textContent =
                "Criar conta de jogador";

            cadastrar.textContent = "Cadastrar jogador";
        } else {
            cadastro.querySelector("h2").textContent =
                `Criar conta de ${tipo.value}`;

            cadastrar.textContent = `Cadastrar ${tipo.value}`;
        }
    }

    tipo.addEventListener("change", atualizarTipo);
    atualizarTipo();

    const retorno = criarMensagem(
        cadastro,
        "mensagem-cadastro"
    );

    function alternarFormulario(mostrarLogin) {
        secao.style.display = mostrarLogin ? "" : "none";
        cadastro.style.display = mostrarLogin ? "none" : "";
    }

    const acessoLogin = criar("p");

    acessoLogin.append(
        document.createTextNode("Já possui uma conta? "),
        criarLink("Entrar", "#entrar")
    );

    cadastro.appendChild(acessoLogin);

    const acessoCadastro = criar("p");

    acessoCadastro.append(
        document.createTextNode("Não possui uma conta? "),
        criarLink("Cadastre-se", "#cadastro")
    );

    secao.appendChild(acessoCadastro);

    function atualizarFormularioPelaUrl() {
        if (window.location.hash === "#entrar") {
            alternarFormulario(true);
        } else if (window.location.hash === "#cadastro") {
            alternarFormulario(false);
        }
    }

    window.addEventListener("hashchange", atualizarFormularioPelaUrl);

    alternarFormulario(
        Boolean(KORA.usuario) ||
        window.location.hash === "#entrar"
    );

    formCadastro.addEventListener("submit", async (evento) => {
        evento.preventDefault();

        await executar(cadastrar, retorno, async () => {
            const emailInformado = email.value.trim().toLowerCase();
            const papel = tipo.value;

            const dados = {
                nome: nome.value.trim(),
                email: emailInformado,
                senha: novaSenha.value
            };

            if (papel === "jogador") {
                dados.nick = nick.value.trim();
            } else {
                dados.papel = papel;
            }

            if (papel === "jogador") {
                await api(
                    "/api/jogadores/cadastrar/",
                    "POST",
                    dados
                );
            } else {
                await api(
                    "/api/equipe/cadastrar/",
                    "POST",
                    dados
                );
            }

            formCadastro.reset();
            atualizarTipo();

            usuario.value = emailInformado;
            senha.value = "";

            avisar(retorno, "");

            if (papel === "jogador") {
                avisar(
                    mensagem,
                    "Cadastro realizado! Entre usando seu e-mail e senha."
                );
            } else {
                avisar(
                    mensagem,
                    "Conta criada! Entre com seu e-mail e senha. As permissões precisam ser aprovadas."
                );
            }

            window.location.hash = "entrar";
            alternarFormulario(true);
            senha.focus();
        });
    });
}
