"use strict";

const KORA = {
    usuario: null,
    perfil: null,
    torneioId: null,
    detalhes: null
};

function buscar(id) {
    return document.getElementById(id);
}

function criar(tag, conteudo = null) {
    const elemento = document.createElement(tag);
    if (conteudo !== null) elemento.textContent = String(conteudo);
    return elemento;
}

function adicionar(pai, tag, conteudo) {
    const elemento = criar(tag, conteudo);
    pai.appendChild(elemento);
    return elemento;
}

function criarMensagem(pai, id = "") {
    const elemento = criar("p");
    if (id) elemento.id = id;
    elemento.setAttribute("role", "status");
    elemento.setAttribute("aria-live", "polite");
    pai.appendChild(elemento);
    return elemento;
}

function avisar(elemento, mensagem, erro = false) {
    if (!elemento) return;
    elemento.textContent = mensagem;
    elemento.style.color = erro ? "#ff9baf" : "";
}

function criarCampo(formulario, rotulo, id, tipo = "text", limite = 45) {
    const grupo = criar("div");
    const label = criar("label", rotulo);
    label.htmlFor = id;
    const input = criar("input");
    input.id = id;
    input.name = id;
    input.type = tipo;
    input.required = true;
    if (tipo !== "password") input.maxLength = limite;
    if (tipo === "password") input.minLength = 8;
    grupo.append(label, input);
    formulario.appendChild(grupo);
    return input;
}

function criarBotao(rotulo, aoClicar) {
    const botao = criar("button", rotulo);
    botao.type = "button";
    botao.addEventListener("click", aoClicar);
    return botao;
}

function criarLink(rotulo, destino) {
    const link = criar("a", rotulo);
    link.href = destino;
    return link;
}

function temPapel(papel) {
    return Boolean(
        KORA.usuario &&
        KORA.usuario.grupos.includes(papel)
    );
}

function habilitar(botao, permitido, explicacao = "") {
    botao.dataset.bloqueado = permitido ? "false" : "true";
    botao.disabled = !permitido;
    botao.title = permitido ? "" : explicacao;
}

async function executar(botao, mensagem, operacao) {
    if (botao.disabled) return;
    botao.disabled = true;
    avisar(mensagem, "Processando...");
    try {
        await operacao();
    } catch (erro) {
        avisar(mensagem, erro.message || "Ocorreu um erro.", true);
    } finally {
        botao.disabled = botao.dataset.bloqueado === "true";
    }
}

async function api(caminho, metodo = "GET", dados = undefined) {
    const opcoes = {
        method: metodo,
        credentials: "same-origin",
        headers: {
            Accept: "application/json"
        }
    };

    if (metodo !== "GET") {
        const respostaCsrf = await fetch("/api/csrf/", {
            credentials: "same-origin"
        });

        if (!respostaCsrf.ok) {
            throw new Error(
                "Não foi possível obter o token de segurança."
            );
        }

        const csrf = await respostaCsrf.json();
        opcoes.headers["X-CSRFToken"] = csrf.csrfToken;
    }

    if (dados !== undefined) {
        opcoes.headers["Content-Type"] = "application/json";
        opcoes.body = JSON.stringify(dados);
    }

    let resposta;

    try {
        resposta = await fetch(caminho, opcoes);
    } catch {
        throw new Error(
            "Não foi possível conectar ao Django. Confira se o servidor está ligado."
        );
    }

    const resultado = await resposta.json().catch(() => ({}));

    if (!resposta.ok) {
        const detalhes = Array.isArray(resultado.detalhes)
            ? " " + resultado.detalhes.join("; ")
            : "";

        const erro = new Error(
            (resultado.erro || `Erro HTTP ${resposta.status}.`) +
            detalhes
        );

        erro.status = resposta.status;
        throw erro;
    }

    return resultado;
}

async function consultarUsuario() {
    try {
        return await api("/api/usuario/");
    } catch (erro) {
        if (erro.status === 401) return null;
        throw erro;
    }
}

function configurarMenu() {
    const menu = document.querySelector("header nav");
    if (!menu) return;

    menu.replaceChildren();
    menu.appendChild(criarLink("Início", "/inicio/"));

    if (!KORA.usuario) {
        menu.appendChild(criarLink("Entrar", "/login/#entrar"));

        if (buscar("sobre")) {
            menu.appendChild(criarLink("Sobre", "#sobre"));
        }

        return;
    }

    if (temPapel("jogador")) {
        menu.appendChild(
            criarLink("Meu perfil", "/inicio/#painel-perfil")
        );
    }

    adicionar(menu, "span", KORA.usuario.usuario);

    const sair = criarBotao("Sair", async () => {
        try {
            await api("/api/logout/", "POST");
            window.location.href = "/login/";
        } catch (erro) {
            window.alert(erro.message);
        }
    });

    menu.appendChild(sair);
}
