"use strict";

const FASES = ["Oitavas de final", "Quartas de final", "Semifinal", "Final"];

const PARTIDAS_POR_FASE = {
    "Oitavas de final": 8,
    "Quartas de final": 4,
    "Semifinal": 2,
    "Final": 1
};

function preencherSelect(seletor, jogadores) {
    seletor.replaceChildren();

    const inicial = criar("option", "Selecione um jogador");
    inicial.value = "";
    seletor.appendChild(inicial);

    jogadores.forEach((jogador) => {
        const opcao = criar("option", jogador.nick);
        opcao.value = String(jogador.id);
        seletor.appendChild(opcao);
    });
}

function criarSelect(formulario, rotulo, id) {
    const grupo = criar("div");
    const label = criar("label", rotulo);
    label.htmlFor = id;

    const select = criar("select");
    select.id = id;
    select.required = true;

    grupo.append(label, select);
    formulario.appendChild(grupo);
    return select;
}

function botaoAcao(rotulo, url, sucesso, { atualizar, mensagem, confirmar }) {
    const botao = criarBotao(rotulo, async () => {
        if (confirmar && !window.confirm(confirmar)) return;

        await executar(botao, mensagem, async () => {
            await api(url, "POST", { torneio_id: KORA.torneioId });
            await atualizar();
            avisar(mensagem, sucesso);
        });
    });
    return botao;
}

function faseAtual(partidas, quantidade) {
    if (!partidas.length) {
        return { 16: FASES[0], 8: FASES[1] }[quantidade] ?? FASES[2];
    }

    return (
        [...FASES].reverse().find((fase) => partidas.some((p) => p.fase === fase)) ??
        FASES[0]
    );
}

function jogadoresDisponiveis(detalhes, fase) {
    const { partidas, jogadores } = detalhes;

    const usados = new Set(
        partidas
            .filter((p) => p.fase === fase)
            .flatMap((p) => p.jogadores.map((j) => j.id))
    );

    const disponiveis = jogadores.filter((j) => !usados.has(j.id));

    const anterior = FASES[FASES.indexOf(fase) - 1];
    const partidasAnteriores = partidas.filter((p) => p.fase === anterior);

    if (!partidasAnteriores.length) return disponiveis;

    const vencedores = new Set(
        partidasAnteriores.flatMap((p) =>
            p.jogadores.filter((j) => j.vitoria).map((j) => j.id)
        )
    );

    return disponiveis.filter((j) => vencedores.has(j.id));
}

function criarPainelOrganizador(principal, mensagem, atualizar) {
    if (!temPapel("organizador")) return null;

    const painel = criar("section");
    painel.id = "painel-organizador";

    adicionar(painel, "h2", "Controles do organizador");
    const instrucoes = adicionar(painel, "p", "Carregando informações do torneio...");

    const opcoes = { atualizar, mensagem };

    const sortear = botaoAcao(
        "Sortear confrontos",
        "/api/partidas/sortear/",
        "Confrontos sorteados com sucesso!",
        { ...opcoes, confirmar: "Iniciar o campeonato e sortear os confrontos?" }
    );
    const avancar = botaoAcao(
        "Avançar para a próxima fase",
        "/api/partidas/avancar-fase/",
        "Próxima fase criada com sucesso!",
        opcoes
    );
    const gerarFinal = botaoAcao(
        "Gerar final",
        "/api/partidas/gerar-final/",
        "Final criada com sucesso!",
        opcoes
    );

    painel.append(sortear, avancar, gerarFinal);

    adicionar(painel, "h3", "Editar campeonato");

    const formEditar = criar("form");
    const nome = criarCampo(formEditar, "Nome", "editar-torneio-nome");
    const codigo = criarCampo(formEditar, "Código", "editar-torneio-codigo");

    const salvar = criar("button", "Salvar alterações");
    salvar.type = "submit";
    formEditar.appendChild(salvar);
    painel.appendChild(formEditar);

    formEditar.addEventListener("submit", (evento) => {
        evento.preventDefault();

        return executar(salvar, mensagem, async () => {
            await api(`/api/torneios/atualizar/${KORA.torneioId}/`, "PUT", {
                nome: nome.value.trim(),
                codigo: codigo.value.trim()
            });
            await atualizar();
            avisar(mensagem, "Campeonato atualizado com sucesso!");
        });
    });

    adicionar(painel, "h3", "Criar partida manualmente");

    const formPartida = criar("form");
    const fase = criarCampo(formPartida, "Fase atual", "fase-partida");
    fase.readOnly = true;

    const jogador1 = criarSelect(formPartida, "Jogador 1", "partida-jogador-1");
    const jogador2 = criarSelect(formPartida, "Jogador 2", "partida-jogador-2");

    const cadastrarPartida = criar("button", "Criar partida");
    cadastrarPartida.type = "submit";
    formPartida.appendChild(cadastrarPartida);

    painel.appendChild(formPartida);
    principal.appendChild(painel);

    formPartida.addEventListener("submit", (evento) => {
        evento.preventDefault();

        return executar(cadastrarPartida, mensagem, async () => {
            const id1 = Number(jogador1.value);
            const id2 = Number(jogador2.value);

            if (!id1 || !id2 || id1 === id2) {
                throw new Error("Selecione dois jogadores diferentes.");
            }

            await api("/api/partidas/cadastrar/", "POST", {
                torneio_id: KORA.torneioId,
                jogador1_id: id1,
                jogador2_id: id2,
                fase: fase.value
            });
            await atualizar();
            avisar(mensagem, "Partida criada com sucesso!");
        });
    });

    return {
        atualizar(detalhes) {
            painel.style.display = detalhes.pode_gerenciar ? "" : "none";
            if (!detalhes.pode_gerenciar) return;

            const { partidas, total_jogadores: quantidade } = detalhes;
            const faseEmAndamento = faseAtual(partidas, quantidade);
            const limite = PARTIDAS_POR_FASE[faseEmAndamento];

            const atuais = partidas.filter((p) => p.fase === faseEmAndamento);
            const concluidas = atuais.length > 0 && atuais.every((p) => p.vencedor);
            const valido = [4, 8, 16].includes(quantidade);

            habilitar(
                sortear,
                valido && !partidas.length,
                "É necessário ter exatamente 4, 8 ou 16 inscritos e nenhuma partida iniciada."
            );

            avancar.textContent =
                faseEmAndamento === FASES[0]
                    ? "Avançar para as quartas de final"
                    : "Avançar para as semifinais";

            habilitar(
                avancar,
                [FASES[0], FASES[1]].includes(faseEmAndamento) &&
                    atuais.length === limite &&
                    concluidas,
                "Confirme todos os vencedores desta fase antes de avançar."
            );

            habilitar(
                gerarFinal,
                faseEmAndamento === "Semifinal" && atuais.length === limite && concluidas,
                "Finalize as duas semifinais antes de gerar a final."
            );

            const disponiveis = jogadoresDisponiveis(detalhes, faseEmAndamento);

            const podeCriar =
                valido &&
                faseEmAndamento !== "Final" &&
                atuais.length < limite &&
                disponiveis.length >= 2;

            habilitar(
                cadastrarPartida,
                podeCriar,
                "Não há vagas ou jogadores suficientes para criar outra partida nesta fase."
            );

            fase.value = faseEmAndamento;

            [jogador1, jogador2].forEach((select) => {
                preencherSelect(select, disponiveis);
                select.disabled = !podeCriar;
            });

            nome.value = detalhes.nome;
            codigo.value = detalhes.codigo || "";
            codigo.parentElement.style.display = detalhes.publico ? "none" : "";
            codigo.required = !detalhes.publico;

            instrucoes.textContent = !partidas.length
                ? valido
                    ? `Há ${quantidade} inscritos. Sorteie os confrontos ou crie as partidas manualmente.`
                    : `Há ${quantidade} inscritos. Para iniciar, são necessários exatamente 4, 8 ou 16 jogadores.`
                : `Fase atual: ${faseEmAndamento}. O juiz confirma os vencedores; o organizador avança as fases.`;
        }
    };
}