"""
URL configuration for sistema project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from sistemas import paginas

urlpatterns = [
    path("", paginas.pagina_login, name="pagina_login"),
    path("login/", paginas.pagina_login, name="login"),
    path("inicio/", paginas.pagina_inicio, name="inicio"),
    path("classificacao/", paginas.pagina_classificacao, name="classificacao"),
    path("admin/", admin.site.urls),
    path("api/", include("sistemas.urls")),
]
